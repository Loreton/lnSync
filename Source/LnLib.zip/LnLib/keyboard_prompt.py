#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 2021-08-27
#
import  sys; sys.dont_write_bytecode = True
import os


########################################################################
# -------------- PROMPT -------------------
########################################################################
def keyb_prompt(msg='', validKeys='ENTER', exitKeys='x|q', displayValidKeys=False, gVars={}):
    # -------------------------------
    def caller_info(message, stacknum=2):
        from inspect import getframeinfo, stack
        caller = getframeinfo(stack()[stacknum][0])
        funcname=os.sep.join(caller.filename.split(os.sep)[-2:])
        msg=f"{funcname}:{caller.lineno} - {message}"
        return msg
    # -------------------------------

    C=gVars['color'] if 'color' in gVars else None

    if not msg:
        print()
        # msg=caller_info('Enter [c] to continue....')
        msg=caller_info('[c] to continue')
        validKeys='c'

    if not validKeys or not displayValidKeys:
        msg = f"     {msg} - ({exitKeys} to exit) ==> "
    else:
        msg = f"     {msg} [{validKeys}] - ({exitKeys} to exit) ==> "



    if C: msg=C.gWhiteH(msg)
    if isinstance(validKeys, (range)):
        _keys = []
        for i in validKeys:
            _keys.append(i)
        validKeys = '|'.join([str(x) for x in _keys])

    validKeys = validKeys.split('|')

    exitKeys = exitKeys.split('|')
    while True:
        choice      = input(msg).strip()
        choiceUPP   = choice.upper()

        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request new.")
            sys.exit(1)

        if choice == '':
            if "ENTER" in exitKeys:
                sys.exit()
            if "ENTER" in validKeys:
                return ''
            else:
                print('\n... please enter something\n')

        elif "ENTER" in validKeys:
            return choice

        elif choice in validKeys:
            break

        else:
            print('\n... try again\n')

    return choice

