#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 25-08-2022 09.28.17

import sys; sys.dont_write_bytecode=True
import os
import yaml
from collections import OrderedDict
import convertionsUtils as dataConv

from LnDict import LoretoDict
# https://gist.github.com/joshbode/569627ced3076931b02f


def readYamlFile_preset(runtime_directory=None):
    global runtime_dir, yaml_runtime_dir, json_runtime_dir

    if runtime_directory:
        runtime_dir=runtime_directory
        yaml_runtime_dir=f'{runtime_dir}/yaml'
        json_runtime_dir=f'{runtime_dir}/json'




#============================================
#- _!include: conf/lnprofile.yaml
#- il nuovo file andrà nella root del dict
#- tested: OK
#============================================
def resolve_include(*, d):
    sep='.'

    fFOUND=True
    while fFOUND:
        fFOUND=False
        flat_dict=d.flatten()
        # flat_dict=LoretoDict(d.flattenT2())

        for keypath, value in flat_dict.items():
            if keypath.endswith("include_files"): # ex: _!include: conf/lnprofile.yaml
                fFOUND=True
                if not sep in keypath:
                    keypath=sep+keypath
                parent, last_key = keypath.rsplit('.', 1)
                
                ptr=d.get_keypath(parent)     # ptr to parent
                del ptr[last_key]                  # remove include_files entry
                for filename in value:
                    _dict=read_file(filename)
                    value=d.merge(keypath=parent, d2=_dict, override=True) # update current










# ----------------------------------------------
# - process all keys for:
#      include#section_name
#       The section_name will be included in the replacing the option include#
#
# - and all values for:
#      @@_get.key1.key2...
# ----------------------------------------------
def resolve_vars(d: dict) -> dict:

    # ------------------------------
    def split_var(value, prefix, suffix):
        left_data, rest = value.split(prefix, 1)
        var_name, rest = rest.split(suffix, 1)
        return left_data, var_name, rest
    # ------------------------------

    pfx_get_dict='${get_dict:'
    pfx_get='${get:'
    pfx_env='${env:'
    ln_dict=LoretoDict(d)
    flat_dict=ln_dict.flatten()
    for keypath, value in flat_dict.items():

        if isinstance(value, str):
            value=os.path.expandvars(value)

            # ------------------------------
            # folders=/tmp/${env:main.MyData}/file.txt
            # ------------------------------
            while pfx_env in value:
                left_data, var_name, rest=split_var(value=value, prefix=pfx_env, suffix="}")
                env_value=os.environ[var_name]
                value=left_data+env_value+rest # importante impostarlo per poter usire dal loop
                value=ln_dict.set_keypath(keypath, value)

            # ------------------------------
            # folders=${get_dict:main.MyData}
            # folders._!_remove_this_key=${get_dict:main.MyData}  remove_this_key will be removed
            # folders=/tmp/${get:main.MyData}
            # folders=/tmp/${get:main.MyData}/file.txt
            # ------------------------------
            while pfx_get_dict in value:
                left_data, var_name, rest=split_var(value=value, prefix=pfx_get_dict, suffix="}")
                value=ln_dict.get_keypath(var_name)

                if keypath.endswith('remove_this_key'):
                    parent, last_key = keypath.rsplit('.', 1)
                    ptr=ln_dict.get_keypath(parent) # ptr to parent
                    del ptr[last_key]                  # remove xxxx_dummy_key entry
                    value=ln_dict.merge(keypath=parent, d2=value, override=False) # update current

                else:
                    value=ln_dict.merge(keypath=keypath, d2=value, override=False)

            # ------------------------------
            # folders=${get:main.MyData}
            # folders=/tmp/${get:main.MyData}
            # folders=/tmp/${get:main.MyData}/file.txt
            # ------------------------------
            while pfx_get in value:
                left_data, var_name, rest=split_var(value=value, prefix=pfx_get, suffix="}")
                value=ln_dict.get_keypath(var_name)
                ln_dict.set_keypath(keypath, value)


    return ln_dict




def read_file(filename):
    if not os.path.exists(filename):
        print(f'File: {filename} not found', filename)
        sys.exit(1)

    with open(filename, 'r') as f:
        content=f.read() # single string

    if isinstance(content, dict):
        my_dict=content
    else:
        my_dict=yaml.load(content, Loader=yaml.SafeLoader)

    ''' l'include Non va bene perché il secondi file va in override al primo '''
    my_dict=resolve_vars(my_dict)
    return my_dict





def loadYamlFile(filename):
    ln_dict=LoretoDict(read_file(filename))
    resolve_include(d=ln_dict)



    '''potrebbe essere utile per variabili cross file... ma da implementare
    my_dict=resolve_vars(_dict)'''

    return ln_dict