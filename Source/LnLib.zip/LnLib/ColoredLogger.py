#!/usr/bin/python
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 26-08-2022 17.45.18
#

##########################################################
# colored Logger con anche la creazione di due ulteriori
# livelli di TRACE e NOTIFY
##########################################################
import colorlog  # https://pypi.org/project/colorlog/
import logging
"""
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "purple": 35,
    "cyan": 36,
    "white": 37,
    "light_black": 90,
    "light_red": 91,
    "light_green": 92,
    "light_yellow": 93,
    "light_blue": 94,
    "light_purple": 95,
    "light_cyan": 96,
    "light_white": 97,
"""
from types import SimpleNamespace


# ==============================================
# - utile per usarla nei display....
# ==============================================
def getColors():
    colors=SimpleNamespace(
        blue       = '\033[0;34m',
        blueH      = '\033[1;34m',
        cyan       = '\033[0;36m',
        cyanH      = '\033[1;36m',
        gray       = '\033[0;37m',
        green      = '\033[0;32m',
        greenH     = '\033[1;32m',
        purple     = '\033[0;35m',
        purpleH    = '\033[1;35m',
        red        = '\033[0;31m',
        redH       = '\033[1;31m',
        white      = '\033[1;37m',
        yellow     = '\033[0;33m',
        yellowH    = '\033[1;33m',
        colorReset = '\033[0m',
    )
    return colors


def setColors(level, logger_name, test=False):
    # ----------------------------
    def getFormatter():
        formatter=colorlog.ColoredFormatter(
            # """%(cyan)s%(asctime)s %(blue)s[%(module)s.%(funcName)s:%(lineno)4s]: %(log_color)s[%(levelname)4s] %(message)s""",
            # """%(cyan)s%(asctime)s %(blue)s[%(module)s.%(funcName)s:%(lineno)4s] - %(log_color)s[%(levelname)4s]: %(message)s""",
            """%(cyan)s%(asctime)s %(log_color)s[%(levelname)4s] - %(blue)s[%(module)s.%(funcName)s:%(lineno)4s]: %(log_color)s%(message)s""",
            datefmt="%H:%M:%S",
            reset=True,
            log_colors={
                'TRACE':    'yellow',
                'DEBUG':    'cyan',
                'NOTIFY':   'fg_bold_cyan',
                'INFO':     'green',
                'FUNCTION': 'purple',
                'WARNING':  'yellow',
                'ERROR':    'red',
                'CRITICAL': 'red,bg_white',
            },
            secondary_log_colors={},
            # secondary_log_colors={ # non ho capito a cosa serve
            #     'message': {
            #         'ERROR':    'green',
            #         'CRITICAL': 'red'
            #     }
            # },
            style='%'
        )
        return formatter

    # --------- Adding TRACE level -------------------
    logging.TRACE = logging.DEBUG-1
    def _trace(logger, message, *args, **kwargs):
        if logger.isEnabledFor(logging.TRACE):
            logger._log(logging.TRACE, message, args, **kwargs)
    logging.Logger.trace = _trace
    logging.addLevelName(logging.TRACE, "TRACE")


    # --------- Adding NOTIFY level -------------------
    logging.NOTIFY = logging.INFO+1
    def _notify(logger, message, *args, **kwargs):
        if logger.isEnabledFor(logging.NOTIFY):
            logger._log(logging.NOTIFY, message, args, **kwargs)
    logging.Logger.notify = _notify
    logging.addLevelName(logging.NOTIFY, "NOTIFY")



    NOTIFY=logging.INFO+1
    logging.addLevelName(NOTIFY, 'NOTIFY')

    handler=logging.StreamHandler()
    handler.setFormatter(getFormatter())

    logger = logging.getLogger(logger_name)
    logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False # se messo a True mi trovo due righe di log, una colorata e l'altra no.

    if test:
        testLogger(logger)
    return logger




def testLogger(logger):
    print()
    logger.debug("this is a DEBUGGING message")
    logger.notify("this is a NOTIFY message")
    logger.info("this is an INFORMATIONAL message")
    logger.warning("this is a WARNING message")
    logger.error("this is an ERROR message")
    logger.trace("this is a TRACE message")
    logger.critical("this is a CRITICAL message")
    print()

