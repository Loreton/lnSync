#!/usr/bin/python
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 17-08-2022 07.55.46


# ---------- LnLIB COMMON Functions ------
# from . Logger.LnLogger                  import LnLogger        as InitLogger
# from . Logger.LnLogger                  import SetLogger        as SetLogger

# from . Common.Exit                     import Exit             as Exit
# from . Common.LnColor                  import LnColor          as Color

# from . Common import MonkeyFunctions # per Path.LnCopy, Path.LnBackup

# from . import LnLib
# from . import Main

# from . LoretoDictionary import LoretoDict
# from . read_ini_file    import readIniFile, resolve_vars

# from Main.coloredLogger import coloredLogger
# from . LnLib.read_ini_file    import readIniFile, resolve_vars

# from utils.lower import to_lower
# from utils.upper import to_upper
# from utils.length import get_length