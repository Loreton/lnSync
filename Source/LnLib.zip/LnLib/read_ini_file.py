#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 25-08-2022 17.14.54

import sys; sys.dont_write_bytecode=True
import os
import configparser
from pathlib import Path


def readIniFile_preset(runtime_directory=None):
    global runtime_dir, yaml_runtime_dir, json_runtime_dir

    if runtime_directory:
        runtime_dir=runtime_directory
        yaml_runtime_dir=f'{runtime_dir}/yaml'
        json_runtime_dir=f'{runtime_dir}/json'


def readIniFile(filename):

    if not os.path.exists(filename):
        print(f'File: {filename} not found', filename)
        sys.exit(1)

    config=configparser.ConfigParser(
                        allow_no_value=False,
                        delimiters=('=', ':'),
                        comment_prefixes=('#',';'),
                        inline_comment_prefixes=(';',),
                        strict=True,          # True: impone unique key/session
                        empty_lines_in_values=False,
                        default_section='DEFAULT',
                        # "interpolation": configparser.ExtendedInterpolation() # mi dà errore con le variabili
                        interpolation=configparser.BasicInterpolation()
                    )

    config.optionxform = str        # mantiene il case nei nomi delle section e delle Keys (Assicurarsi che i riferimenti a vars interne siano case-sensitive)
    config.read(filename)

    dictionary = {}
    for section in config.sections():
        dictionary[section] = {}
        for option in config.options(section):
            dictionary[section][option] = config.get(section, option)

    dictionary=resolve_vars(dictionary, filename)

    return dictionary



# ----------------------------------------------
# - process all keys for:
#      include#section_name
#       The section_name will be included in the replacing the option include#
#
# - and all values for:
#      @@_get.key1.key2...
# ----------------------------------------------
def resolve_vars(config: dict, filename: str) -> dict:
    sections=list(config.keys()) # to avoid RuntimeError: dictionary changed size during iteration
    for section in sections:
        items=list(config[section].items())
        for key, value in items:

            # --- include full section
            if key.startswith('include#'):
                section_to_include=key.split('#')[1] # get section name to be included
                config[section].pop(key) # remove current key entry
                aa=config[section_to_include]
                config[section].update(aa)

            # --- env vars and eternal section reference
            elif isinstance(value, str):
                value=os.path.expandvars(value)

                while "${env:" in value:
                    value=resolve_env(value)

                while "${get:" in value:
                    value=resolve_get(value, config)

                config[section][key]=value

    return config



def resolve_env(data, prefix='${env:', suffix='}'):
    left_data, rest = data.split(prefix, 1)
    var_name, rest = rest.split(suffix, 1)
    env_value=os.environ[var_name]
    value=left_data+env_value+rest
    return value


def resolve_get(data, config, prefix='${get:', suffix='}'):
    left_data, rest = data.split(prefix, 1)
    keypath, rest = rest.split(suffix, 1)

    ptr=config
    for level_key in keypath.split('.'):
        ptr=ptr[level_key]
    value=ptr

    return value