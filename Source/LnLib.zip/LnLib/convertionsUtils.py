#!/usr/bin/python
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 2021-08-27
import  sys; sys.dont_write_bytecode = True
import  os
import json, yaml
import copy
from pathlib import Path, PosixPath
from    benedict import benedict

this=sys.modules[__name__]
logger=None

# use logging module for easy debug
import logging
logging.basicConfig(format='%(asctime)s %(levelname)8s: %(message)s', datefmt='%m-%d %H:%M:%S')
logger=logging.getLogger(__name__)
# logger.setLevel('DEBUG')
logger.setLevel('WARNING')

def setup(myLogger):
    global logger
    # logger=myLogger

def kill_myself(logger=None, telegramBotPointer=None):
    import signal
    data=logger.get_stack_trace(fPrint=True)
    if telegramBotPointer:
        pass

    os.kill(os.getpid(), signal.SIGTERM)
    sys.exit(1)


def writeYamlFile(*, d, file_out, title=None, indent=4, sort_keys=False, replace=False):
    yaml_data=dict_to_yaml(d=d, title=title, indent=indent, sort_keys=sort_keys)
    return writeTextFile(data=yaml_data, file_out=file_out, replace=replace)


def writeJsonFile(*, d, file_out, titel=None, indent=4, sort_keys=False, replace=False):
    json_data=dict_to_json(d=d, title=title, indent=indent, sort_keys=sort_keys)
    return writeTextFile(data=json_data, file_out=file_out, replace=replace)


def dict_to_yaml(d, title=None, indent=4, sort_keys=True):
    # tutto il giro per evitare che compaiano dei rifetimenti strani di benedict nel'output
    _dict={title: d} if title else d # add title
    _json_str=json.dumps(_dict) # convert benedict to json_str
    _json_dict=json.loads(_json_str) # convert json_str to dict
    return yaml.dump(_json_dict, indent=indent, sort_keys=sort_keys, default_flow_style=False)




def dict_to_json(d, indent=4, sort_keys=True):
    return json.dumps(d, indent=indent, sort_keys=sort_keys, separators=(',', ': '), default=str)



def print_Json(d, **kwargs):
    print(dict_to_json(d=d, **kwargs))


def print_Yaml(d, **kwargs):
    print(dict_to_yaml(d=d, **kwargs))


def readJsonFile(*, file_in: (str, os.PathLike)):
    with open(file_in) as f:
        config = json.load(f)
    return config



def writeTextFile(*, data, file_out: (str, os.PathLike) , replace=False):
    logger.debug('writing file: %s', file_out)
    fileError=True
    file_out=Path(file_out)

    if file_out.exists() and replace is False:
        fWRITE=False
    else:
        fWRITE=True

    if isinstance(data, list):
        data='\n'.join(data)

    if fWRITE:
        os.makedirs(file_out.parent,  exist_ok=True)
        with open(file_out, "w") as f:
            f.write(f'{data}\n')
        fileError=False
    else:
        logger.warning('ERROR: file %s already exists.', file_out )

    return fileError





# https://www.freecodecamp.org/news/how-to-flatten-a-dictionary-in-python-in-4-different-ways/
from collections.abc import MutableMapping
def _flatten_dict_gen(d, parent_key, sep):
    for k, v in d.items():
        new_key = parent_key + sep + k if parent_key else k
        if isinstance(v, MutableMapping):
            yield from flatten_T2(v, new_key, sep=sep).items()
        else:
            yield new_key, v


def flatten_T2(d: MutableMapping, parent_key: str = '', sep: str = '.'):
    return dict(_flatten_dict_gen(d, parent_key, sep))


def flatten_T1(dictionary, parent_key=False, separator='.'):
    import  collections
    items = []
    for key, value in dictionary.items():
        new_key = f"{parent_key}{separator}{key}" if parent_key else key
        if isinstance(value, MutableMapping):
            items.extend(flatten(value, new_key, separator).items())
        elif isinstance(value, list):
            for k, v in enumerate(value):
                items.extend(flatten({str(k): v}, new_key).items())
        else:
            items.append((new_key, value))
    return dict(items)



try:
    from    benedict import benedict
    benedict.toJson = dict_to_json  # per non fare override original
    benedict.toYaml = dict_to_yaml  # per non fare override original
    benedict.flatten = flatten
    benedict.pJson = print_Json
    benedict.pYaml = print_Yaml
except:
    pass




# try:
#     from    LnDict import lnDict
#     lnDict.toJson = dict_to_json  # per non fare override original
#     lnDict.toYaml = dict_to_yaml  # per non fare override original
#     # lnDict.flatten = flatten_T1
#     lnDict.pJson = print_Json
#     lnDict.pYaml = print_Yaml
# except:
#     pass






######################################################
# -
######################################################
def getDictPath(d: dict, keypaths: list=[], default=None):

    if isinstance(d, benedict):
        for keypath in keypaths:
            value=d.get(keypath, None)
            if value:
                break

    else:
        for keypath in keypaths:
            ptr=d
            for token in keypath.split('.'):
                if token in ptr:
                    ptr=ptr[token]
                else:
                    ptr=default
                    break # leave internal loop
            if ptr:
                value=ptr
                break # leave main loop

    if not value:
        logger.warning("NO value found for keypaths: %s", keypaths)
        value=default

    return value