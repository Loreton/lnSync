#!/usr/bin/python
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 2021-08-27
import  sys; sys.dont_write_bytecode = True
import  os
import json, yaml
import copy
from pathlib import Path, PosixPath
from    benedict import benedict

this=sys.modules[__name__]
logger=None

# use logging module for easy debug
import logging
logging.basicConfig(format='%(asctime)s %(levelname)8s: %(message)s', datefmt='%m-%d %H:%M:%S')
logger=logging.getLogger(__name__)
# logger.setLevel('DEBUG')
logger.setLevel('WARNING')

def setup(myLogger):
    global logger
    # logger=myLogger

def kill_myself(logger=None, telegramBotPointer=None):
    import signal
    data=logger.get_stack_trace(fPrint=True)
    if telegramBotPointer:
        pass

    os.kill(os.getpid(), signal.SIGTERM)
    sys.exit(1)


def writeYamlFile(*, d, file_out, indent=4, sort_keys=False, replace=False):
    yaml_data=dict_to_yaml(d=d, indent=indent, sort_keys=sort_keys)
    return writeData(data=yaml_data, file_out=file_out, replace=replace)

def writeJsonFile(*, d, file_out, indent=4, sort_keys=False, replace=False):
    json_data=dict_to_json(d=d, indent=indent, sort_keys=sort_keys)
    return writeData(data=json_data, file_out=file_out, replace=replace)

def dict_to_yaml(d, indent=4, sort_keys=True):
    return yaml.dump(d, indent=indent, sort_keys=sort_keys, default_flow_style=False)

def dict_to_json(d, indent=4, sort_keys=True):
    return json.dumps(d, indent=indent, sort_keys=sort_keys, separators=(',', ': '), default=str)

def print_Json(d, title='', **kwargs):
    _dict={title: d} if title else d
    print(dict_to_json(d=_dict, **kwargs))


def print_Yaml(d, title='', **kwargs):
    # tutto il giro per evitare che compaiano dei rifetimenti strani di benedict nel'output
    # print(dict_to_yaml(d=_dict, indent=indent, sort_keys=sort_keys))
    _dict={title: d} if title else d # add title
    _json_str=json.dumps(_dict) # convert benedict to json_str
    _json_dict=json.loads(_json_str) # convert json_str to dict
    print(dict_to_yaml(d=_json_dict, **kwargs))




def readJsonFile(*, file_in: (str, os.PathLike)):
    with open(file_in) as f:
        config = json.load(f)
    return config



def writeTextFile(*, data, file_out: (str, os.PathLike) , replace=False):
    logger.debug('writing file: %s', file_out)
    fileError=True
    file_out=Path(file_out)

    if file_out.exists() and replace is False:
        fWRITE=False
    else:
        fWRITE=True

    if isinstance(data, list):
        data='\n'.join(data)

    if fWRITE:
        os.makedirs(file_out.parent,  exist_ok=True)
        with open(file_out, "w") as f:
            f.write(f'{data}\n')
        fileError=False
    else:
        logger.warning('ERROR: file %s already exists.', file_out )

    return fileError

writeData=writeTextFile



########################################################################
# -------------- PROMPT -------------------
########################################################################
def prompt(msg='', validKeys='ENTER', exitKeys='x|q', displayValidKeys=False, gVars={}):
    # -------------------------------
    def caller_info(message, stacknum=2):
        from inspect import getframeinfo, stack
        caller = getframeinfo(stack()[stacknum][0])
        funcname=os.sep.join(caller.filename.split(os.sep)[-2:])
        msg=f"{funcname}:{caller.lineno} - {message}"
        return msg
    # -------------------------------

    C=gVars['color'] if 'color' in gVars else None

    if not msg:
        print()
        # msg=caller_info('Enter [c] to continue....')
        msg=caller_info('[c] to continue')
        validKeys='c'

    if not validKeys or not displayValidKeys:
        msg = f"     {msg} - ({exitKeys} to exit) ==> "
    else:
        msg = f"     {msg} [{validKeys}] - ({exitKeys} to exit) ==> "



    if C: msg=C.gWhiteH(msg)
    if isinstance(validKeys, (range)):
        _keys = []
        for i in validKeys:
            _keys.append(i)
        validKeys = '|'.join([str(x) for x in _keys])

    validKeys = validKeys.split('|')

    exitKeys = exitKeys.split('|')
    while True:
        choice      = input(msg).strip()
        choiceUPP   = choice.upper()

        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request new.")
            sys.exit(1)

        if choice == '':
            if "ENTER" in exitKeys:
                sys.exit()
            if "ENTER" in validKeys:
                return ''
            else:
                print('\n... please enter something\n')

        elif "ENTER" in validKeys:
            return choice

        elif choice in validKeys:
            break

        else:
            print('\n... try again\n')

    return choice



def flatten(dictionary, parent_key=False, separator='.'):
    import  collections
    """
    Turn a nested dictionary into a flattened dictionary
    :param dictionary: The dictionary to flatten
    :param parent_key: The string to prepend to dictionary's keys
    :param separator: The string used to separate flattened keys
    :return: A flattened dictionary
    """

    items = []
    for key, value in dictionary.items():
        # new_key = str(parent_key) + separator + key if parent_key else key
        new_key = f"{parent_key}{separator}{key}" if parent_key else key
        if isinstance(value, collections.abc.MutableMapping):
            items.extend(flatten(value, new_key, separator).items())
        elif isinstance(value, list):
            for k, v in enumerate(value):
                items.extend(flatten({str(k): v}, new_key).items())
        else:
            items.append((new_key, value))
    return dict(items)



try:
    from    benedict import benedict
    benedict.dict_to_json = dict_to_json  # per non fare override original
    benedict.dict_to_yaml = dict_to_yaml  # per non fare override original
    benedict.flatten = flatten
    benedict.print_json = print_Json
    benedict.print_yaml = print_Yaml
except:
    pass




######################################################
# -
######################################################
def getDictPath(d: dict, keypaths: list=[], default=None):
    # value=default
    if isinstance(d, benedict):
        for keypath in keypaths:
            value=d.get(keypath, None)
            if value:
                break

    else:
        for keypath in keypaths:
            ptr=d
            for token in keypath.split('.'):
                if token in ptr:
                    ptr=ptr[token]
                else:
                    ptr=default
                    break # leave internal loop
            if ptr:
                value=ptr
                break # leave main loop

    if not value:
        logger.warning("NO value found for keypaths: %s", keypaths)
        value=default

    return value