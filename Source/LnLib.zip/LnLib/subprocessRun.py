#!/usr/bin/python
# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 2021-10-15
#
# #############################################

import sys; sys.dont_write_bytecode=True
import subprocess, shlex

'''
subprocess.run was added in Python 3.5 as a simplification over subprocess.
Popen when you just want to execute a command and wait until it finishes,
but you don’t want to do anything else meanwhile.
For other cases, you still need to use subprocess.Popen.

The main difference is that subprocess.run executes a command and waits for it to finish, while with subprocess.
Popen you can continue doing your stuff while the process finishes and then just repeatedly
call subprocess.communicate yourself to pass and receive data to your process.

Note that, what subprocess.run is actually doing is invoking for you the Popen and communicate,
so you don’t need to make a loop to pass/receive data nor wait for the process to finish.
'''


class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=functions=info=notify=debug=trace=dummy


# def setLogger(my_logger=nullLogger()):
#     global logger
#     logger=my_logger

# setLogger()





def run_sh_single_output(cmd, exit_on_error=False, no_log_errors=False, logger=nullLogger()):
    logger.debug('executing command: %s', cmd)
    splitted_cmd=shlex.split(cmd)

    try:
        p1 = subprocess.run(splitted_cmd, # waits for it to finish
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,              # changed from universal_newlines=True,
                        check=True,             # non-zero exit code, a CalledProcessError exception will be raised.
                        )

        rcode=p1.returncode
        output=p1.stdout if hasattr(p1, 'stdout') else p1.output
        _stderr=p1.stderr

        logger.debug('rcode: %s ', rcode)
        logger.debug('output: %s', output)


    except (Exception) as e:
        rcode=1
        output=None
        _stderr=str(e)
        logger.error("error: %s", _stderr)

        if exit_on_error:
            logger.critical('exiting on exit_on_error flag')
            sys.exit(1)

    return rcode, output




def run_sh(cmd, logger=nullLogger(), exit_on_error=False, no_log_errors=False):
    splitted_cmd=shlex.split(cmd)
    logger.debug('executing command: %s', cmd)
    stdout=stderr=''
    try:
        p1 = subprocess.run(splitted_cmd, # waits for it to finish
                        capture_output=True,    # stdout=PIPE and stderr=PIPE.
                        text=True,              # changed from universal_newlines=True,
                        check=True,             # non-zero exit code, a CalledProcessError exception will be raised.
                        )

        rcode=p1.returncode
        stdout=p1.stdout if hasattr(p1, 'stdout') else p1.output
        stderr=p1.stderr

        logger.debug('rcode: %s ', rcode)
        logger.debug('stdout: %s', stdout)
        logger.debug('stderr: %s', stderr)

    except (Exception) as e:
        rcode=1
        stderr=str(e)
        logger.error("error: %s", stderr)

        if exit_on_error:
            logger.critical('exiting on exit_on_error flag')
            sys.exit(1)

    return rcode, stdout, stderr


def run_sh_pipe(cmd1, cmd2):
    p1 = subprocess.Popen(shlex.split(cmd1), stdout=subprocess.PIPE, universal_newlines=True)
    p2 = subprocess.Popen(shlex.split(cmd2), stdin=p1.stdout, stdout=subprocess.PIPE, universal_newlines=True)
    p1.stdout.close()  # Allow p1 to receive a SIGPIPE if p2 exits.
    output = p2.communicate()[0]
    # output = output.decode('UTF-8') # non serve se si usa ,universal_newlines=True
    print(output)





if __name__ == '__main__':
    run_sh_pipe(cmd1='dmesg', cmd2='grep sda')
    run_sh_pipe(cmd1='hostname -I', cmd2="cut -d' ' -f1")
    run_sh(cmd='hostname -I')
    run_sh(cmd='nc -w 5 -z rm-pina.duckdns.org 8023')
    SQ="'"
    DQ='"'
    run_sh(cmd="/usr/bin/ssh -i /home/pi/.ssh/my_tunnel_key -o ConnectTimeout=10 -o BatchMode=yes -o StrictHostKeyChecking=no -l pi -p 8023 rm-pina.duckdns.org {DQ}hostname -I | cut -d{SQ} {SQ} -f1{DQ}".format(**locals()))
    run_sh(cmd="/usr/bin/ssh -i /home/pi/.ssh/my_tunnel_key -o ConnectTimeout=10 -o BatchMode=yes -o StrictHostKeyChecking=no   -l pi -p 8023 rm-pina.duckdns.org nc -w 5 -z 192.168.1.23 64032".format(**locals()))
