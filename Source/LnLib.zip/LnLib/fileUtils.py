#!/usr/bin/python
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 2021-08-27
import  sys; sys.dont_write_bytecode = True
import  os
import json, yaml
from pathlib import Path, PosixPath

class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=info=debug=dummy

def writeTextFile(*, data, file_out: (str, os.PathLike) , replace=False, logger=nullLogger()):
    logger.debug('writing file: %s', file_out)

    file_out=Path(file_out)

    if file_out.exists() and replace is False:
        logger.error('file %s already exists. No changes', file_out )
        return ''

    if isinstance(data, list):
        data='\n'.join(data)

    os.makedirs(file_out.parent,  exist_ok=True)
    with open(file_out, "w") as f:
        f.write(f'{data}\n')

    return str(file_out)


