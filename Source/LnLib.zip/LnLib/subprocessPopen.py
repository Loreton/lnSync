#!/usr/bin/python
# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 2021-10-15
#
# #############################################

import sys; sys.dont_write_bytecode=True
import subprocess, shlex

'''
subprocess.run was added in Python 3.5 as a simplification over subprocess.
Popen when you just want to execute a command and wait until it finishes,
but you don’t want to do anything else meanwhile.
For other cases, you still need to use subprocess.Popen.

The main difference is that subprocess.run executes a command and waits for it to finish, while with subprocess.
Popen you can continue doing your stuff while the process finishes and then just repeatedly
call subprocess.communicate yourself to pass and receive data to your process.

Note that, what subprocess.run is actually doing is invoking for you the Popen and communicate,
so you don’t need to make a loop to pass/receive data nor wait for the process to finish.
'''




class nullLogger():
    def dummy(self,  title, *args, **kwargs):
        pass
    critical=error=warning=info=debug=dummy




import fcntl
import os
import subprocess
import time

# def runCommand(cmdline, output=False, out_to_file=False, logger=nullLogger(), timeout=9999999, max_stdout_size=0):
#     kwargs={
#         "logger": logger,
#         "timeout": timeout,
#         "max_stdout_size": max_stdout_size,
#     }

#     if type=='continuous_output':
#         runCommand_continuous_output(cmdline, **kwargs)
#     elif type=='continuous_output':
#         runCommand_continuous_output(cmdline, **kwargs)



def nonBlockRead(output):
    fd = output.fileno()
    fl = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
    try:
        return output.read()
    except:
        return ''



######################################################################
# continuous output
# stdxxx_file:      invia stdout e stderr acnhe su file
# timeout:          se lo si supera chiude il processo
# max_stdout_size:  massimo size di stdout e stderr variables per ragioni di memoria
######################################################################
def runCommand(cmdline, logger=nullLogger(), timeout=9999999, max_stdout_size=0, stdout_file=None, stderr_file=None, console=False):
    #------------------------------------------
    #  by Loreto:  20-08-2022 10.04.49
    # https://discuss.dizzycoding.com/python-subprocess-with-timeout-and-large-output-64k/
    #------------------------------------------
    def checkTimeOut():
        if elapsed_time >= timeout:
            try:
                p.stdout.close()  # If they are not closed the fds will hang around until
                p.stderr.close()  # os.fdlimit is exceeded and cause a nasty exception
                p.terminate()     # Important to close the fds prior to terminating the process!
                                  # NOTE: Are there any other "non-freed" resources?
                returncode = 5
                print('ERROR: Timeout ({timeout} sec.) occurred! Process terminated.')
            except:
                pass


    def savedata(init=False):
        if init:
            if os.path.exists(stdout_file):
                os.remove(stdout_file)
            if os.path.exists(stderr_file):
                os.remove(stderr_file)
            return

        if stdout_file:
            with open(stdout_file, 'a') as f:
                f.write(stdout)
            logger.debug('file: %s has been written', stdout_file)

        if stderr_file:
            with open(stderr_file, 'a') as f:
                f.write(stderr)
            logger.debug('file: %s has been written', stderr_file)

    splitted_cmd=shlex.split(cmdline)


    p = subprocess.Popen(
        splitted_cmd,
        bufsize = 0, # default value of 0 (unbuffered) is best
        shell   = False, # not really needed; it's disabled by default
        stdout  = subprocess.PIPE,
        stderr  = subprocess.PIPE,
        text=True,
    )


    t_begin = time.time() # Monitor execution time
    elapsed_time = 0

    savedata(init=True)

    redH='\033[1;31m'
    yellowH='\033[1;33m'
    colorReset='\033[0m'

    stdout = ''
    stderr = ''
    while p.poll() is None and elapsed_time < timeout: # Monitor process
        time.sleep(0.1) # Wait a little
        elapsed_time=time.time() - t_begin
        '''p.std* blocks on read(), which messes up the timeout timer.
            To fix this, we use a nonblocking read()
            Note: Not sure if this is Windows compatible '''
        data_out = nonBlockRead(p.stdout)
        if data_out:
            if console: print(data_out)
            stdout += data_out
            if max_stdout_size>0 and len(stdout) > max_stdout_size: # per evitare di andare inontro a memoria piena sacrifico l'output
                print('------- flushing stdout ----------------')
                p.stdout.flush()
                stdout=''

        data_err = nonBlockRead(p.stderr)
        if data_err:
            if console:
                print(data_err.replace('ERROR', redH+"ERROR"+colorReset))
            stderr += data_err
            if max_stdout_size>0 and len(stderr) > max_stdout_size: # per evitare di andare inontro a memoria piena sacrifico l'output
                print('------- flushing stderrs ----------------')
                p.stderr.flush()
                stderr=''

    # at the end...
    savedata()
    returncode = p.returncode
    checkTimeOut()


    return (returncode, stdout, stderr)






if __name__ == '__main__':
    run_sh_pipe(cmd1='dmesg', cmd2='grep sda')
    run_sh_pipe(cmd1='hostname -I', cmd2="cut -d' ' -f1")
    run_sh(cmd='hostname -I')
    run_sh(cmd='nc -w 5 -z rm-pina.duckdns.org 8023')
    SQ="'"
    DQ='"'
    run_sh(cmd="/usr/bin/ssh -i /home/pi/.ssh/my_tunnel_key -o ConnectTimeout=10 -o BatchMode=yes -o StrictHostKeyChecking=no -l pi -p 8023 rm-pina.duckdns.org {DQ}hostname -I | cut -d{SQ} {SQ} -f1{DQ}".format(**locals()))
    run_sh(cmd="/usr/bin/ssh -i /home/pi/.ssh/my_tunnel_key -o ConnectTimeout=10 -o BatchMode=yes -o StrictHostKeyChecking=no   -l pi -p 8023 rm-pina.duckdns.org nc -w 5 -z 192.168.1.23 64032".format(**locals()))
