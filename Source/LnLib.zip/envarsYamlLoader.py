#!/usr/bin/python
# -*- coding: utf-8 -*-

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 11-12-2022 17.58.09
#
# #############################################
__ln_version__="YamlLoader V2022-12-11_175809"

import  sys; sys.dont_write_bytecode=True
import  os
from types import SimpleNamespace
import json
import socket; hostname=socket.gethostname()

if __name__ == '__main__':
    sys.path.insert(0, '/home/loreto/GIT-REPO/Python/LnPyLib/Dictionary')

from LoretoDict import LnDict; d_dummy=LnDict()




class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=functions=info=notify=debug=trace=caller=dummy



#####################################################
#  gv.mqttmonitor_runtime_dir
#  gv.envars_dir
#####################################################
def setup(gVars):
    global gv, logger
    gv=gVars
    logger=gv.logger if gv.logger else nullLogger()
    envars_dir              = gv.envars_dir
    # mqttmonitor_runtime_dir = gv.mqttmonitor_runtime_dir






##########################################################################
# keypath is string whith keys separated by dot
#       key1.key2.....keyn
# cast is the returned dictionary type (lortodict, OrderedDict, ...)
##########################################################################
def loadYamlFile(filename, keypath: str=None, cast: dict=dict):
    import yaml
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            content=f.read() # single string
    else:
        logger.caller('File: %s not found', filename)
        sys.exit(1)

    ### resolve env vars
    content=os.path.expandvars(content)

    ### load as dict
    my_data=yaml.load(content, Loader=yaml.SafeLoader)

    if keypath:
        ptr=my_data
        keypath=keypath.split('.')
        for key in keypath:
            if key in ptr:
                ptr=ptr[key]
            else:
                logger.caller('key %s (from keypath: %s) not found', key, keypath)
                ptr=None
                break

        my_data=ptr

    if 'lndict' in str(cast).lower():  #  by Loreto:  18-11-2022 12.02.54
        return cast(my_data)
    else:
        return my_data


def mariaDB_data(keypath: str=None, cast: dict=dict):
    filename=f"${gv.envars_dir}/yaml/mariadb.yaml"
    data=loadYamlFile(filename=filename, keypath=keypath, cast=cast)
    return data






###############################################
# per i bot, partendo dall'alias risaliamo al nome del bot associato
# return:
#  channel_alias or group_alias:
#      LnPi22_channel:
#          chat_id: -1001508748849
#          group_name: LnPi22_channel
#          type: channel
#          bot_name: LnChannelBot
#
# is_channel: force search only on channels
###############################################
def retrieveBotData(*, alias_name: str, is_channel: bool=False):
    data=telegramGroup_data(keypath='telegram')


    if is_channel==False and alias_name in data['groups'].keys():
        bot=data['groups'][alias_name]

    elif alias_name in data['channels'].keys():
        bot=data['channels'][alias_name]

    else:
        bot={}

    if bot:
        bot_name=bot["bot_name"]
        bot["token"]=data['bots'][bot_name]["token"]

    return bot


###############################################
#
###############################################
def telegramGroup_data(keypath: str=None):
    filename=f"{gv.envars_dir}/yaml/telegramGroups.yaml"
    data=loadYamlFile(filename=filename, keypath=keypath)
    return data




def mqttBroker(broker_name: str):
    filename=f"{gv.envars_dir}/yaml/Mqtt_Brokers.yaml"
    data=loadYamlFile(filename=filename, keypath=f"brokers.{broker_name}")
    return data






    #################################################
    # Load device json file
    # created by mqttmonitor.py
    #################################################
def mqttmonitorDevice(device_name: str):
    filename=f'{gv.mqttmonitor_runtime_dir}/{device_name}.json'
    device={}
    if os.path.exists(filename) and os.stat(filename).st_size>0:
        with open(filename, 'r') as fin:
            device=json.load(fin)

    return device





if __name__ == '__main__':
    gVars=SimpleNamespace()
    gVars.logger=nullLogger()
    gVars.envars_dir="/home/loreto/.ln/envars"
    setup(gVars=gVars)

    bot=retrieveBotData(alias_name=hostname)
    print(d_dummy.to_json(d=bot))