#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 2021-05-03
#
# Scope:  aggiunge dei metodi al package python-benedict e DotMap
# ######################################################################################

import sys; sys.dont_write_bytecode=True
import os
import yaml
import json
from pathlib import Path



class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=functions=info=notify=debug=trace=caller=dummy

def setup(*, gVars):
    global logger
    logger=gVars.logger if gVars.logger else nullLogger()




def print_json( **kwargs):
    print(toJson(**kwargs))

def print_yaml( **kwargs):
    print(toYaml(**kwargs))




def toJson(d: dict, filepath: str=None, title: str=None, indent=4, sort_keys=False):
    _dict={title: d} if title else d
    json_data=json.dumps(_dict, indent=indent, sort_keys=sort_keys, separators=(',', ': '), default=str)

    if filepath:
        return writeTextFile(data=json_data, file_out=filepath, replace=True)
    else:
        return json_data


def toYaml(d: dict, filepath: str=None, title: str=None, indent=4, sort_keys=False):
    # tutto il giro per evitare che compaiano dei rifetimenti strani di benedict nel'output
    _dict={title: d} if title else d # add title
    _json_str=json.dumps(_dict) # convert benedict to json_str
    _json_dict=json.loads(_json_str) # convert json_str to dict
    yaml_data=yaml.dump(_json_dict, indent=indent, sort_keys=sort_keys, default_flow_style=False)
    if filepath:
        return writeTextFile(data=yaml_data, file_out=filepath, replace=True)
    else:
        return yaml_data

def toYamlFile(d: dict, filepath: str, title: str=None, indent=4, sort_keys=False, replace=False):
    yaml_data=toYaml(d=d, title=title, indent=indent, sort_keys=sort_keys)
    return writeTextFile(data=yaml_data, file_out=filepath, replace=replace)


def toJsonFile(d: dict, filepath: str, title: str=None, indent=4, sort_keys=False, replace=False):
    json_data=toJson(d=d, title=title, indent=indent, sort_keys=sort_keys)
    return writeTextFile(data=json_data, file_out=filepath, replace=replace)





######################################################
# -
######################################################
def writeTextFile(*, data, filename: (str, os.PathLike) , replace=False):
    fileError=True
    filepath=Path(filename).resolve()
    logger.debug('writing file: %s', filepath)

    if filepath.exists() and replace is False:
        fWRITE=False
    else:
        fWRITE=True

    if isinstance(data, list):
        data='\n'.join(data)

    if fWRITE:
        os.makedirs(filepath.parent,  exist_ok=True)
        with open(filepath, "w") as f:
            f.write(f'{data}\n')
        fileError=False
    else:
        logger.warning('ERROR: file %s already exists.', filepath )

    return fileError






########################################################################
# -------------- PROMPT -------------------
########################################################################
def keyb_prompt(msg='', validKeys='ENTER', exitKeys='x|q', displayValidKeys=False, gVars={}):
    # -------------------------------
    def caller_info(message, stacknum=2):
        from inspect import getframeinfo, stack
        caller = getframeinfo(stack()[stacknum][0])
        funcname=os.sep.join(caller.filename.split(os.sep)[-2:])
        msg=f"{funcname}:{caller.lineno} - {message}"
        return msg
    # -------------------------------

    C=gVars['color'] if 'color' in gVars else None

    print()
    if not msg:
        # msg=caller_info('Enter [c] to continue....')
        msg=caller_info('[c] to continue')
        validKeys='c'

    if not validKeys or not displayValidKeys:
        msg = f"     {msg} - ({exitKeys} to exit) ==> "
    else:
        msg = f"     {msg} [{validKeys}] - ({exitKeys} to exit) ==> "



    if C: msg=C.gWhiteH(msg)
    if isinstance(validKeys, (range)):
        _keys = []
        for i in validKeys:
            _keys.append(i)
        validKeys = '|'.join([str(x) for x in _keys])

    validKeys = validKeys.split('|')

    exitKeys = exitKeys.split('|')
    while True:
        choice      = input(msg).strip()
        choiceUPP   = choice.upper()

        if choice in exitKeys: # diamo priorità all'uscita
            print("Exiting on user request.")
            sys.exit(0)

        if choice == '':
            if "ENTER" in exitKeys:
                sys.exit()
            if "ENTER" in validKeys:
                return ''
            else:
                print('\n... please enter something\n')

        elif "ENTER" in validKeys:
            return choice

        elif choice in validKeys:
            break

        else:
            print('\n... try again\n')

    return choice




#################################################################
# r = d.search(in_keys, in_keys=True, in_values=False, exact=True, case_sensitive=True)
# m = d.match(in_keys, indexes=True)
# f = d.find(['a.b.c', 'e.d.q'], default=0)
#################################################################
def benedict_search(d: dict, in_str: str, first_match=False):
    _keys = d.keypaths(indexes=False) ### benedict function
    valids=[_key for _key in _keys if in_str in _key]
    if valids and first_match:
        return valids[0]

    return valids




######################################################
# - Monkeys
######################################################
try:
    from dotmap import DotMap
    DotMap.toJson = _toJson
    DotMap.toYaml = _toYaml
except:
    pass

try:
    from benedict import benedict
    benedict.toYamlFile = toYamlFile # esiste anche il default di benedict.toYaml(filepath=xxx)
    benedict.toJsonFile = toJsonFile  # esiste anche il default di benedict.to_jso(filepath=xxx)
    benedict.in_key = benedict_search  # esiste anche il default di benedict.to_jso(filepath=xxx)
except:
    pass





def _test_dict():
    my_servers="""
        SERVER:
            S01:
                alias: ln_s01
                ssh_port: s01_1000
                host: 192.168.1.01
                credentials:
                    username: user_s01
                    password: passw_01
                location:
                    building: B01
                    floar: 1
                    room: 14
            S02:
                alias: ln_s02
                ssh_port: s02_2000
                host: 192.168.1.02
                credentials:
                    username: user_s02
                    password: passw_02
                location:
                    building: B02
                    floar: 2
                    room: 24
            servers:
            - server1:
                s11: s1_s01
                s12: s1_s02
            - server2:
                s21: s2_s01
                s22: s2_s02
            - server3:
                - s31: s3_s01
                - s32: s3_s02
       """
    server_dict=yaml.load(my_servers, Loader=yaml.SafeLoader)
    return server_dict



#######################################################
#
#######################################################
if __name__ == '__main__':
    # from types import SimpleNamespace
    # gVars=SimpleNamespace()
    # gVars.logger=nullLogger()
    # setup(gVars=gVars)
    d=benedict(__test_dict())
    # r = d.ln_search('POWER', in_keys=True, in_values=False, exact=False, case_sensitive=True)
    # r = d.ln_search(in_keys="SERVER")
    r = d.in_key(in_str="building", first_match=True)
    print(r)
    r = d.in_key(in_str="building", first_match=False)
    print(r)
    r = d.in_key(in_str="buildingx", first_match=False)
    print(r)
