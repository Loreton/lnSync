#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -*- coding: iso-8859-1 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 11-12-2022 08.45.14

import sys; sys.dont_write_bytecode=True
import os
import yaml, json
from collections import OrderedDict
from collections.abc import MutableMapping
from pathlib import Path


# __all__ = ['dict']

# try:
#     import builtins
# except ImportError:
#     import __builtin__ as builtins



class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=functions=info=notify=debug=trace=caller=dummy

def setup(*, gVars):
    global logger
    logger=gVars.logger if gVars.logger else nullLogger()



class LnDict(OrderedDict):
    def __init__(self, *args, **kwargs):
        self.separator='.'
        super(LnDict, self).__init__(*args, **kwargs)


    #------------------------------------------
    #-
    #------------------------------------------
    # def __missing__(self, key):
    #     result = self[key] = self.default_factory()
    #     return result

    #------------------------------------------
    #- Non cambia nulla se ci sono o meno
    #------------------------------------------
    # def __getattr__(self, key):
    #     OrderedDict.__getattr__(self, key)
    # def __setattr__(self, key):
    #     OrderedDict.__setattr__(self, key)

    # def __getattr__(self, key):
    #     try:
    #         return self[key]
    #     except KeyError:
    #         return super(LnDict(), self).__getattr__(key)



    # def _returnLnDict(self, data):
    #     if isinstance(data, dict):
    #         return LnDict(data)

    #==========================================================
    # keypath: "key1.key2.key3...." or ["key1", "key2", "key3"]
    #==========================================================
    # def get(self, key, sep='.', exit_on_not_found=True) -> dict:
    #     if not sep in key:
    #         return OrderedDict.get(key)


    def _isdict(self, obj):
        return isinstance(obj, dict)

    def __getitem__(self, key):
        if self.separator in key:
            return self.get_keypath(keypath=key)
        return super().__getitem__(key)



    #==========================================================
    # keypath: "key1.key2.key3...." or ["key1", "key2", "key3"]
    #==========================================================
    def get_keypath(self, *, keypath: (str, list), sep: str='.', default=None, exit_on_not_found=True) -> dict:
        ptr=self
        if isinstance(keypath, str):
            keypath=keypath.split(sep)

        for key in keypath:
            if key in ptr:
                ptr=ptr[key]

            else:
                ptr=None

        if ptr is None:
            logger.caller("part of keypath: %s NOT found", keypath)
            return default

        elif self._isdict(ptr):  # recursive
            return type(self)(ptr)

        return ptr



        # data=super().__getitem__(key)
        # return self._returnLnDict(data)
        # return super(LnDict, self).__getitem__(key)
        # x=self.get(key)
        #return self[key]
        #return self.get(key) # purtroppo perdo il type LnDict

    # def pop(self, key):
        # return super().pop(key)


    """
    ### NON FUNZIONA
    def __setitem__(self, key, value):
        if self.sep in key:
            return self.set_keypath(keypaths=key, value=value, create=True)
        self[key]=value
    """





    #==========================================================
    # per utilizzare i metodi anche con dictionary diversi da self
    # creare un oggetto tipo: static=LnDict()
    # dopo di che posso utilizzare il metodo:
    #    myLnDict.keys(key_patterns=['a'])
    #    static.keys(d=otherDict, key_patterns=['a'])
    #==========================================================


    def key_startswith(self, pattern: str='', d=OrderedDict()):
        if not d: d=self
        keys = [k for k in d.keys() if k.startswith(pattern)]
        key = keys[0] if keys else None
        return d.get(key)

    def in_key(self,  pattern: str='', d=OrderedDict()):
        if not d: d=self
        keys = [k for k in d.keys() if pattern in k]
        key = keys[0] if keys else None
        return key
    '''

    # @staticmethod
    def keys2(self, pattern='', d=OrderedDict()):
        if not d: d=self
        _keys=[ k for k in d.keys() if pattern in k] # tutte le key che contengono 'pattern'
        return _keys

    def keys3(self, patterns=[], d=OrderedDict()):
        if not d: d=self
        keys=[ k for k in d.keys() for pattern in patterns if pattern in k] # tutte le key che contengono 'pattern'
        return keys


    '''

    def first_key(self, pattern='', d=OrderedDict(), cut=False, return_value=False, default=dict()):
        d=d if d else self
        _flatten_data=self.flatten(d)
        key=next( (k for k in _flatten_data.keys() if pattern in k), default ) # la prossima key che contiene pattern

        if key==default:
            return default

        # crea una key con  il primo qualificatore del keypath e aggiunge il pattern
        if cut:
            token=key.split(pattern)
            key=token[0] + pattern

        if return_value:
            return d[key]
        else:
            return key



    #############################################################
    # ritorna la lista delle keys() (key_path)
    # che rispondono ai patterns
    #############################################################
    def keySearch(self, d=OrderedDict(),  key_patterns=[], value_patterns=[]) -> list:
        if not d: d=self
        _flatten_data=self.flatten(d)

        items=[]
        if key_patterns:
            for key_path in _flatten_data.keys():
                for _str in key_patterns:
                    if _str in key_path:
                        items.append((key_path, _flatten_data[key_path]))

            _flatten_data=dict(items)


        items=[]
        if value_patterns:
            for key_path, value in _flatten_data.items():
                if isinstance(value, str):
                    for _str in value_patterns:
                        if _str in value:
                            items.append((key_path, value))
            _flatten_data=dict(items)


        return list(_flatten_data.keys())








    #==========================================================
    # keypath: "key1.key2.key3...." or ["key1.key2", "key1.key3"]
    #==========================================================
    def get_keypaths_XXXXXX(self, *, keypaths: list, sep: str='.', default=None, exit_on_not_found=True) -> dict:
        if isinstance(keypaths, str): keypaths=[keypaths]

        def _keypath(keypath):
            ptr=self
            keypath=keypath.split(sep)
            for key in keypath:
                if key.isnumeric(): # cerca di indiviruale l'indice di una lista.
                    ptr=ptr[int(key)]

                elif key in ptr:
                    ptr=ptr[key]

                else:
                    return None

            if self._isdict(ptr):  # recursive
                return type(self)(ptr)

            return ptr


        for keypath in keypaths:
            ptr=_keypath(keypath)
            if not ptr is None:
                return ptr

        logger.caller("part of keypath: %s NOT found", keypath)

        return default






    #==========================================================
    # keypath: "key1.key2.key3...." or ["key1", "key2", "key3"]
    #==========================================================
    def set_keypath(self, keypath: (str, list), value, sep: str='.', create=True) -> dict:
        if isinstance(keypath, str):
            keypath=keypath.split(sep)

        ptr=self
        last_key=keypath[-1]

        for key in keypath:
            if key in ptr:
                ptr=ptr[key]
            else:
                if create:
                    ptr[key]=dict()
                    ptr=ptr[key]
                else:
                    logger.error("key: %s part of keypath: %s NOT found", key, keypath)


        if isinstance(value, dict):
            ptr.update(value)
        else:
            ptr=value

        return ptr


    #==========================================================
    # keypath: "key1.key2.key3...." or ["key1", "key2", "key3"]
    #==========================================================
    def set_keypath_list_XXXXXX(self, keypath: (str, list), value, sep: str='.', create=True) -> dict:
        if isinstance(keypath, str):
            keypath=keypath.split(sep)

        ptr=self
        last_key=keypath[-1]
        # Se l'ultimo qualificatore è numerico vuol dire che è una LIST
        if last_key.isnumeric():
            index=int(last_key)
            last_key=keypath[-2]
        else:
            index=-1

        for key in keypath[:-1]:
            if key in ptr:
                ptr=ptr[key]
            else:
                if create:
                    ptr[key]=OrderedDict()
                    ptr=ptr[key]
                else:
                    logger.error("key: %s part of keypath: %s NOT found", key, keypath)

        if index >= 0:
            ptr[index]=value
        else:
            if isinstance(value, dict):
                ptr[last_key].update(value)
            else:
                ptr[last_key]=value

        return ptr


    #==========================================================
    # return d1 updated
    #==========================================================
    def merge(self, keypath: (str, list), d2: dict, override=False) -> dict:
        d1=self.get_keypath(keypath=keypath)
        return merge(d1=d1, d2=d2, override=override)


    #==========================================================
    # torna gli item delle liste come singole path
    #==========================================================
    def flattenType1(self, d: dict=OrderedDict(), parent_key=False, separator='.'):
        if not d: d=self
        items = []
        for key, value in d.items():
            new_key = f"{parent_key}{separator}{key}" if parent_key else key
            if isinstance(value, MutableMapping):
                items.extend(self.flattenType1(value, new_key, separator).items())
            elif isinstance(value, list):
                for k, v in enumerate(value):
                    items.extend(self.flattenType1({str(k): v}, new_key).items())
            else:
                items.append((new_key, value))

        return dict(items)


    #==========================================================
    # tormìna la lista come lista.
    #==========================================================
    def flattenType1a(self, d: dict=OrderedDict(), parent_key=False, separator='.', key_str=None, value_str=None, explode_list=False):
        if not d: d=self
        items = []
        for key, value in d.items():
            new_key = f"{parent_key}{separator}{key}" if parent_key else key
            if isinstance(value, MutableMapping):
                items.extend(self.flattenType1a(d=value, parent_key=new_key, separator=separator, key_str=key_str, value_str=value_str, explode_list=explode_list).items())
            elif explode_list and isinstance(value, list):
                for k, v in enumerate(value):
                    items.extend(self.flattenType1a(d={str(k): v}, parent_key=new_key, key_str=key_str, value_str=value_str, explode_list=explode_list).items())
            else:
                if key_str: # search in key
                    if isinstance(key, str) and key_str in key:
                        items.append((new_key, value))

                elif value_str: # search in value
                    if isinstance(value, str) and value_str in value:
                        items.append((new_key, value))

                else: # insert all
                    items.append((new_key, value))


        return dict(items)


    #==========================================================
    # torna la lista come lista.
    #==========================================================
    def flattenType1b(self, d: dict=dict(), parent_key=False, search_key=[], search_value=[], explode_list=False):
        if not d: d=self
        sep=self.separator
        items = []
        for key, value in d.items():
            new_key = f"{parent_key}{sep}{key}" if parent_key else key
            if isinstance(value, MutableMapping):
                items.extend(self.flattenType1b(d=value, parent_key=new_key, search_key=search_key, search_value=search_value, explode_list=explode_list).items())
            elif explode_list and isinstance(value, list):
                for k, v in enumerate(value):
                    items.extend(self.flattenType1b(d={str(k): v}, parent_key=new_key, search_key=search_key, search_value=search_value, explode_list=explode_list).items())
            else:
                if isinstance(key, str):
                    for _str in search_key:
                        if _str in key: # search in key
                            items.append((new_key, value))

                if isinstance(value, str):
                    for _str in search_value:
                        if _str in value: # search in value
                            items.append((new_key, value))

                else: # insert all
                    items.append((new_key, value))


        return dict(items)


    #==========================================================
    # NON esplode le list
    # https://www.freecodecamp.org/news/how-to-flatten-a-dictionary-in-python-in-4-different-ways/
    #==========================================================
    def flatten(self, d=OrderedDict(),  parent_key: str='', sep: str='.') -> dict:
        if not d: d=self
        return dict(self._flatten_dict_gen(d, parent_key, sep))

    def _flatten_dict_gen(self, d, parent_key, sep):
        for k, v in d.items():
            new_key = parent_key + sep + k if parent_key else k
            if isinstance(v, MutableMapping):
                yield from self.flatten(v, new_key, sep=sep).items()
            else:
                yield new_key, v








    def print_json(self,  **kwargs):
        print(self.to_json(**kwargs))

    def print_yaml(self,  **kwargs):
        print(self.to_yaml(**kwargs))


    def to_json(self, d: dict={}, title: str=None, indent=4, sort_keys=True):
        if not d: d=self
        _dict={title: d} if title else d
        return json.dumps(_dict, indent=indent, sort_keys=sort_keys, separators=(',', ': '), default=str)


    def to_yaml(self, d: dict={}, title: str=None, indent=4, sort_keys=True):
        if not d: d=self
        # tutto il giro per evitare che compaiano dei rifetimenti strani di benedict nel'output
        _dict={title: d} if title else d # add title
        _json_str=json.dumps(_dict) # convert benedict to json_str
        _json_dict=json.loads(_json_str) # convert json_str to dict
        return yaml.dump(_json_dict, indent=indent, sort_keys=sort_keys, default_flow_style=False)


    def toYamlFile(self, filename, d: dict={}, title: str=None, indent=4, sort_keys=False, replace=False):
        if not d: d=self
        yaml_data=self.to_yaml(d=d, title=title, indent=indent, sort_keys=sort_keys)
        return self.writeTextFile(data=yaml_data, file_out=filename, replace=replace)


    def toJsonFile(self, filename, d: dict={}, title: str=None, indent=4, sort_keys=False, replace=False):
        if not d: d=self
        json_data=self.to_json(d=d, title=title, indent=indent, sort_keys=sort_keys)
        return self.writeTextFile(data=json_data, file_out=filename, replace=replace)





    ######################################################
    # -
    ######################################################
    def writeTextFile(self, *, data, file_out: (str, os.PathLike) , replace=False):
        logger.debug('writing file: %s', file_out)
        fileError=True
        file_out=Path(file_out)

        if file_out.exists() and replace is False:
            fWRITE=False
        else:
            fWRITE=True

        if isinstance(data, list):
            data='\n'.join(data)

        if fWRITE:
            os.makedirs(file_out.parent,  exist_ok=True)
            with open(file_out, "w") as f:
                f.write(f'{data}\n')
            fileError=False
        else:
            logger.warning('ERROR: file %s already exists.', file_out )

        return fileError




#==========================================================
# return d1 updated
#==========================================================
def merge(d1: dict, d2: dict, override=False) -> dict:
    if override:
        d1.update(d2)
    else:
        dx=OrderedDict() # create new dict
        dx.update(d2)   # copy d2
        dx.update(d1)   # merge d1
        d1.update(dx)   # move result to d1

    return LnDict(d1)





def __test_dict():
    my_servers="""
        SERVER:
            S01:
                alias: ln_s01
                ssh_port: s01_1000
                host: 192.168.1.01
                credentials:
                    username: user_s01
                    password: passw_01
                location:
                    building: B01
                    floar: 1
                    room: 14
            S02:
                alias: ln_s02
                ssh_port: s02_2000
                host: 192.168.1.02
                credentials:
                    username: user_s02
                    password: passw_02
                location:
                    building: B02
                    floar: 2
                    room: 24
            servers:
            - server1:
                s11: s1_s01
                s12: s1_s02
            - server2:
                s21: s2_s01
                s22: s2_s02
            - server3:
                - s31: s3_s01
                - s32: s3_s02
       """
    server_dict=yaml.load(my_servers, Loader=yaml.SafeLoader)
    return server_dict



#######################################################
#
#######################################################
if __name__ == '__main__':
    from types import SimpleNamespace
    gVars=SimpleNamespace()
    gVars.logger=nullLogger()
    setup(gVars=gVars)
    serverDict=__test_dict()

    myDict=LnDict({'name': 'Jack', 'age': 26})
    myDict.print_json(title='my dictionary'); print()


    myDict['Loreto']=LnDict()
    myDict['Loreto']['level2']=LnDict()
    myDict['Loreto']['level2']['level3']='level3'
    myDict.print_json(title='changing 01');print()


    ptr=myDict['Loreto.level2']
    ptr['level3']=LnDict()
    ptr=myDict['Loreto']['level2']
    ptr['level3']=LnDict()
    myDict.print_json(title='changing 03');print()

    ptr=ptr['level3']
    ptr['ohhh']='ciao'
    myDict.print_json(title='changing 04');print()

    kp=['Loreto.level2.level3']
    xx=myDict.get_keypath(keypath=kp, exit_on_not_found=True)
    print(f"xx = keypaths({kp}) =  {xx}"); print("is xx dict?:", isinstance(xx, dict));print()

    # xx=myDict.keypath('Loreto1.level2.level3', default='ciao', exit_on_not_found=True)
    myDict.set_keypath('Loreto.level2.level31.level4', value='ciao', create=True)
    myDict.set_keypath('Loreto1', value='ciao', create=True)
    myDict.set_keypath('', value='empty', create=True)
    myDict.set_keypath('Loreto.level2.lista', value=['l0', 'l1', 'l2'], create=True)
    myDict.set_keypath('Loreto.level2.lista.0', value=['l00', 'l01', 'l02'], create=True)
    myDict.print_json(title='changing 05');print()



    kp='Loreto.level2.lista.0'
    xx=myDict.get_keypath(keypath=kp)
    print(f"xx = keypaths({kp}) =  {xx}"); print("is xx list?:", isinstance(xx, list));print()

    kp='Loreto.level2.lista.1'
    xx=myDict.get_keypath(keypath=kp)
    print(f"xx = keypaths({kp}) =  {xx}"); print("is xx list?:", isinstance(xx, list));print()

    xx=myDict['Loreto']
    xx=myDict.key_startswith('xLoret')
    xx=myDict.in_key('ret')

    kp='Loreto.level2.level31.level4'
    xx=myDict.get(kp) # return None
    print(f"xx = keypaths({kp}) =  {xx}"); print("is xx dict?:", isinstance(xx, dict));print()

    xx=myDict['Loreto']
    xx=myDict['Loreto.level2.level31']
    print(f"xx = keypaths({kp}) =  {xx}"); print("is xx dict?:", isinstance(xx, dict));print()



    import pdb; pdb.set_trace(); pass # by Loreto
    flatmyDict=myDict.flatten()
    flatmyDict.print_json(title='flatten dict')
    print()


    # flatmyDict=LnDict(myDict.flattenType1())
    # flatmyDict.print_json(title='flattenType1 dict')
    # print()

    # flatmyDict=LnDict(myDict.flattenType1a())
    # flatmyDict.print_json(title='flattenType1a dict')
    # print()

    # flatmyDict=LnDict(myDict.flattenType1b())
    # flatmyDict.print_json(title='flattenType1b dict')
    # print()

    ### modo per utilizzare un metodo di LnDict come fosse statico
    ### Tutti i metodi si devono aspettare un eventuale dictionary
    ### creo un'istanza vuota per poi accedere ai metodi con il dict esterno
    _x=LnDict()
    _x.print_json(title='ciao', d=serverDict)
    _x.toYamlFile(filename='/tmp/lnDict_test.yaml', d=serverDict)
